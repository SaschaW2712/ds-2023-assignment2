package com.ds.assignment2;

public class AggregationServerManager {
    public static void main(String[] args) {

        // Use three replicas, so we can use a majority agreement on diverging information
        AggregationServer replica1 = new AggregationServer();
        AggregationServer replica2 = new AggregationServer();
        AggregationServer replica3 = new AggregationServer();


    }
}
